
EMOTIONS = ['Angry', 'Disgusted', 'Fearful','Happy', 'Sad', 'Surprise', 'Neutral']

SPECIAL_EMOTIONS  = ['Other', 'None']