#!/usr/bin/env python
# coding: utf-8

import argparse
from webcam_utils import realtime_emotions
from prediction_utils import prediction_path
from emotion_recommend import recommend_by_emotion
from logger import *
import json
import time
import easydict
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw 
from flask import Flask, request, jsonify

rest_api_host = '141.223.65.26'
rest_api_port = 5000

def emotion_detection(img_str):
    return prediction_path(img_str)

def rest_api_work():
    app = Flask(__name__)

    @app.route('/emotion', methods = ['POST'])
    def analysisEmotion():
        logger.info('Emotion Request')
        try:
            imageData = request.get_json()['image']
            emotion = emotion_detection(imageData)
            emotion_request_json = jsonify({'analysis_result': emotion})
            
            logger.info('Result : ' + emotion + '\n')
            return emotion_request_json
        except Exception as e:
            logger.error(e)

    @app.route('/recommend', methods = ['POST'])
    def analysisEmotionAndReturnRecommends():
        logger.info('Recommendations Request')
        try:
            imageData = request.get_json()['image']
            path = request.get_json()['path']
            emotion = emotion_detection(imageData)
            recommended_list = recommend_by_emotion(emotion, path)
            emotion_request_json = jsonify({
                    'header': 'EMOTIONAL_STATE',
                    'analysis_result':emotion,
                    'recommended_list':recommended_list
                    })

            logger.info('Result : ' + emotion)
            logger.info('Recommends : ' + json.dumps(recommended_list) + '\n')
            return emotion_request_json
        except Exception as e:
            logger.error(e)

    @app.route('/wakeup', methods = ['GET'])
    def wakeup():
        logger.info('Wakeup Request' + '\n')
        try:
            wakeup_request_json = jsonify({'status': 'open'}) 
            return wakeup_request_json
        except Exception as e:
            logger.error(e)

    app.run(host=rest_api_host, port=rest_api_port)

rest_api_work()
